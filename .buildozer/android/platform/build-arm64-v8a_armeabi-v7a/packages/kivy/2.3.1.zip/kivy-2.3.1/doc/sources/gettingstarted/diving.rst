Diving in
---------

To get straight into kivy, take a look at :doc:`/index`.

Kivy comes with a set of :doc:`examples` (`Gallery of Examples <../examples/gallery.html>`_)
in the ``kivy_installation/examples`` directory. You should try
modifying/improving/adapting them to your needs.

Browse our `wiki <https://github.com/kivy/kivy/wiki>`_ for info on related
projects, tutorials and snippets.

Understand the basics about :doc:`/api-kivy.graphics`.

Take a look at the built-in :doc:`/api-kivy.uix`.

Follow the :doc:`/guide-index` to get even more familiar with kivy.

See how to use different :doc:`/api-kivy.modules` in the modules section,
such as the :doc:`/api-kivy.modules.inspector` for live inspection.

Learn how to handle custom :doc:`/api-kivy.input`.

Familiarize yourself with the :mod:`Kivy Framework <kivy>`.

Kivy is open source, so you can **contribute**. Take a look at the
`our latest Contribution Guide <https://github.com/kivy/kivy/blob/master/CONTRIBUTING.md>`_.
